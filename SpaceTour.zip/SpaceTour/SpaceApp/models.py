from django.db import models
from django.contrib import admin

# Create your models here.
class Company(models.Model):
    name = models.CharField(max_length=100)
    logo = models.ImageField(upload_to='images')
    url = models.URLField()
    desc = models.TextField(max_length=300)

    def __str__(self):
        return f"{self.name}"

admin.site.register(Company)

class Stay(models.Model):
    name = models.CharField(max_length=100)
    logo = models.ImageField(upload_to='images')
    url = models.URLField()
    desc = models.TextField(max_length=300)

    def __str__(self):
        return f"{self.name}"

admin.site.register(Stay)


