from django.apps import AppConfig


class SpaceappConfig(AppConfig):
    name = 'SpaceApp'
