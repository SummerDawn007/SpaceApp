from django.shortcuts import render
from SpaceApp.models import *

# Create your views here.
def home(request):
    companies = Company.objects.all()
    context = {
        'companies': companies,
    }
    return render(request, 'home.html', context)

def flights(request):
    companies = Company.objects.all()
    context = {
        'companies': companies,
    }
    return render(request, 'flights.html', context)

def stays(request):
    stays = Stay.objects.all()
    context = {
        'stays': stays,
    }
    return render(request, 'stays.html', context)

def news(request):
    companies = Company.objects.all()
    context = {
        'companies': companies,
    }
    return render(request, 'news.html', context)

def contact(request):
    companies = Company.objects.all()
    context = {
        'companies': companies,
    }
    return render(request, 'contact.html', context)

def main(request):
    i = get_object_or_404(Image, pk=1)
    return render_to_response('SpaceApp/home.html', {'image': i}, context_instance=RequestContext(request))